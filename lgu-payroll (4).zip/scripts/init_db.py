"""Create the database file now (the app also does this automatically on first start).
Run from the project folder:  python scripts/init_db.py [path/to/payroll.db]"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
os.environ["DB_PATH"] = sys.argv[1] if len(sys.argv) > 1 else os.path.abspath("backend/payroll.db")
import sqlite3
from app import main
tables = [r[0] for r in sqlite3.connect(os.environ["DB_PATH"]).execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY 1")]
print("Database ready:", os.environ["DB_PATH"]); print("Tables:", ", ".join(tables))
