#!/usr/bin/env bash
# Daily cron: 0 1 * * * /opt/lgu-payroll/scripts/backup.sh
set -euo pipefail
DEST=${DEST:-/backups}; STAMP=$(date +%F)
mkdir -p "$DEST"
docker compose exec -T app python - <<PY
import sqlite3; s=sqlite3.connect("/data/payroll.db"); d=sqlite3.connect("/data/backup.db"); s.backup(d)
PY
docker compose cp app:/data/backup.db "$DEST/payroll-$STAMP.db"
find "$DEST" -name 'payroll-*.db' -mtime +30 -delete
# Offsite copy (configure once with `rclone config`): rclone copy "$DEST" offsite:payroll-backups
# Restore test: sqlite3 payroll-DATE.db "select count(*) from payslips;"
