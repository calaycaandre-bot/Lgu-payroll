# Municipal Payroll (Philippine LGU prototype)
Run locally:  cd backend && pip install -r requirements.txt && PYTHONPATH=. uvicorn app.main:app --host 0.0.0.0 --reload  (open http://localhost:8000)
Sign in: the only account is AdminRMZDS (set ADMIN_USER / ADMIN_PASS in .env to change). The admin can add departments and employees, run payroll and approve it.
Deploy: cp .env.example .env (set INITIAL_PASSWORD), set your domain in Caddyfile, then `docker compose up -d`.
Roles: HR adds employees; Accounting runs draft payroll; Treasurer approves. Every action is written to the audit table.
VERIFY before real use: GSIS 9%, PhilHealth 5%, Pag-IBIG 2% (cap 10,000), BIR TRAIN monthly table. Allowance treated as PERA (non-taxable).
Not yet built: attendance/DTR import, loans, 13th month, payslip PDF, two-factor login, monitoring (add Uptime Kuma), SQLite->PostgreSQL migration.

Phone access: connect the phone to the SAME Wi-Fi as the laptop, find the laptop IP (Windows: ipconfig, look for IPv4), then open http://LAPTOP-IP:8000 on the phone. Allow port 8000 in the Windows firewall if asked. localhost only works on the laptop itself.

Database: tables are defined in backend/app/schema.sql and created automatically (file: payroll.db). Or run `python scripts/init_db.py`. View/edit it with the free DB Browser for SQLite. When you update the code, KEEP your existing payroll.db or you lose your data.
